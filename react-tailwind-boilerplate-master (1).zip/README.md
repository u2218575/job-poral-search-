# React and Tailwind Boilerplate

Just `npm install`
