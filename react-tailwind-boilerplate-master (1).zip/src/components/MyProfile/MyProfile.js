import axios from "axios";
import React, { useContext, useEffect, useState } from "react";
import { useNavigate } from "react-router";
import AuthContext from "../context/auth-context";
import FileUpload from "../FileUpload/FileUpload";
const baseUrl = process.env.REACT_APP_SERVER_URL;

const MyProfile = () => {
  const auth = useContext(AuthContext);
  const navigate = useNavigate();
  var isSessionLogin = sessionStorage.getItem("isLoggedIn");
  const loginUserId = sessionStorage.getItem("UserId");
  const [error, setError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [progress, setProgress] = useState(false);
  const [Profilesuccess, setProfileSuccess] = useState(false);
  const [uploadFile, setuploadFile] = useState({});
  // const [userProfileData, setuserProfileData] = useState({});
  const [MyProfile, setMyProfile] = useState({
    firstName: "",
    lastName: "",
    emailId: "",
    mobileNo: "",
    gender: "",
    skills: "",
    fileName: "",
  });

  useEffect(() => {
    if (!auth.isLoggedIn && !isSessionLogin) navigate(`/`);
    if (!auth.isLoggedIn && isSessionLogin) auth.login();
    fetch();
  }, [auth.isLoggedIn]);

  const fetch = async () => {
    try {
      const { data } = await axios.get(
        `${baseUrl}/user/get-userprofile?UId=${loginUserId}`
      );
      // setuserProfileData(data.myProfile);
      setMyProfile(data.myProfile);
      setuploadFile(JSON.parse(data.myProfile.fileName));
      // if (Object.keys(data.myProfile.fileName).length !== 0) {
      //   ref.current.handleUpload(JSON.parse(data.myProfile?.fileName));
      // }
    } catch (err) {
      console.error(err);
    }
  };
  const handleOnChange = ({ target }) => {
    const { name, value } = target;
    setMyProfile({ ...MyProfile, [name]: value });
    // setuserProfileData(MyProfile);
    setError("");
  };

  const callbackFunction = (fileData) => {
    setuploadFile(fileData);
  };

  const handleOnClick = async () => {
    try {
      const { firstName, lastName, emailId, mobileNo, gender, skills } =
        MyProfile;
      const data = new FormData();
      data.append("firstName", firstName);
      data.append("lastName", lastName);
      data.append("emailId", emailId);
      data.append("mobileNo", mobileNo);
      data.append("gender", gender);
      data.append("skills", skills);
      data.append(
        "fileName",
        JSON.stringify({
          fileName: uploadFile.name,
          fileSize: uploadFile.size,
          fileType: uploadFile.type,
        })
      );
      data.append("fileData", uploadFile);
      data.append("userId", loginUserId);
      console.log("uplll", uploadFile);

      await axios
        .post(`${baseUrl}/user/save`, data)
        .then((response) => {
          setProfileSuccess(true);
          setMyProfile(response.data);
          console.log(Profilesuccess);
          setProgress(false);
          setSuccessMessage("Profile Saved Successfully!");
          navigate(`/MyProfile`);
        })
        .catch((error) => {
          setProgress(false);
          setMyProfile({
            firstName: "",
            lastName: "",
            emailId: "",
            mobileNo: "",
            gender: "",
            skills: "",
            fileName: {},
            userId: "",
          });
          console.log(error);
          setError(
            error.response?.data?.error === undefined
              ? error.message
              : error.response?.data?.error
          );
        });
    } catch (error) {
      setMyProfile({
        firstName: "",
        lastName: "",
        emailId: "",
        mobileNo: "",
        gender: "",
        skills: "",
        fileName: {},
        userId: "",
      });
      console.log(error);
      setError(error.message);
    }
  };

  return (
    <>
      <h1>My Profile</h1>
      {error && (
        <p className="text-center p-2 mb-3 bg-red-500 text-white rounded-lg">
          {error}
        </p>
      )}
      {!progress && Profilesuccess && (
        <p className="text-center p-2 mb-3 bg-green-500 text-white">
          {successMessage}
        </p>
      )}
      <div className="flex row left-px">
        <div className="flex-col space-y-6 space-x-8">
          <label className="form-label block mb-1 text-sm text-gray-600">
            First Name
          </label>
          <input
            type="text"
            placeholder="First Name"
            name="firstName"
            value={MyProfile?.firstName}
            onChange={handleOnChange}
            className="px-3 text-lg h-10 w-60 border-gray-500 border-2 rounded"
          />
        </div>
      </div>
      <div className="flex row left-px">
        <div className="flex-col space-y-6 space-x-8">
          <label className="form-label block mb-1 text-sm text-gray-600">
            Last Name
          </label>
          <input
            type="text"
            placeholder="Last Name"
            name="lastName"
            value={MyProfile?.lastName}
            onChange={handleOnChange}
            className="px-3 text-lg h-10 w-60 border-gray-500 border-2 rounded"
          />
        </div>
      </div>
      <div className="flex row left-px">
        <div className="flex-col space-y-6 space-x-8">
          <label className="form-label block mb-1 text-sm text-gray-600">
            Email Id
          </label>
          <input
            type="text"
            placeholder="Email Id"
            name="emailId"
            value={MyProfile?.emailId}
            onChange={handleOnChange}
            className="px-3 text-lg h-10 w-60 border-gray-500 border-2 rounded"
          />
        </div>
      </div>
      <div className="flex row left-px">
        <div className="flex-col space-y-6 space-x-8">
          <label className="form-label block mb-2 text-sm text-gray-600">
            Mobile No
          </label>
          <input
            type="text"
            placeholder="Mobile No"
            name="mobileNo"
            value={MyProfile?.mobileNo}
            onChange={handleOnChange}
            className="px-3 text-lg h-10 w-60 border-gray-500 border-2 rounded"
          />
        </div>
      </div>
      <div className="flex row left-px">
        <div className="flex-col space-y-6 space-x-8">
          <label className="form-label block mb-2 text-sm text-gray-600">
            Gender
          </label>
          <input
            type="text"
            placeholder="Gender"
            name="gender"
            value={MyProfile?.gender}
            onChange={handleOnChange}
            className="px-3 text-lg h-10 w-60 border-gray-500 border-2 rounded"
          />
        </div>
      </div>
      <div className="flex row left-px">
        <div className="flex-col space-y-6 space-x-8">
          <label className="form-label block mb-1 text-sm text-gray-600">
            Skills
          </label>
          <input
            type="text"
            placeholder="Skills"
            name="skills"
            value={MyProfile?.skills}
            onChange={handleOnChange}
            className="px-3 text-lg h-10 w-60 border-gray-500 border-2 rounded"
          />
        </div>
      </div>
      <div className="flex row left-px">
        <div className="flex-col space-y-6 space-x-8">
          <label className="form-label block mb-1 text-sm text-gray-600">
            Upload Resume
          </label>
          <FileUpload toChild={uploadFile} sendToParent={callbackFunction} />
        </div>
      </div>
      <div className="flex row left-px">
        <div className="flex-col space-y-6 space-x-8">
          <label className="form-label block mb-1 text-sm text-gray-600"></label>
          <input
            type="submit"
            name="Save"
            className="w-40 h-30 login-button login-button-color"
            onClick={handleOnClick}
          />
        </div>
      </div>
    </>
  );
};

export default MyProfile;
