const Logout = () => {
  return <h1> Logout</h1>;
};

export default Logout;
