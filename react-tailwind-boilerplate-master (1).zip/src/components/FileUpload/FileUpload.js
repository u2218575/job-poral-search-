import React, { useEffect } from "react";

/**
 * Component to handle file upload. Works for image
 * uploads, but can be edited to work for any file.
 */
const FileUpload = (props) => {
  // State to store uploaded file
  const [uploadfile, setuploadFile] = React.useState("");

  // Handles file upload event and updates state
  function handleUpload(event) {
    console.log("555", event);
    setuploadFile(event.target.files[0]);

    // Add code here to upload file to server
    // ...
    props.sendToParent(event.target.files[0]);
  }
  useEffect(() => {
    console.log(props.toChild);
    if (!Object.keys(props.toChild).length === 0)
      setuploadFile(JSON.parse(props.toChild));
  }, [uploadfile]);

  const ImageThumb = ({ image }) => {
    return (
      <img
        src={URL.createObjectURL(image)}
        alt={image.name}
        className={"h-20 w-20"}
      />
    );
  };

  return (
    <div id="upload-box">
      <input type="file" onChange={handleUpload} />
      <p>Filename: {uploadfile.name}</p>
      <p>File type: {uploadfile.type}</p>
      <p>File size: {uploadfile.size} bytes</p>
      {uploadfile && <ImageThumb image={uploadfile} />}
    </div>
  );
};

export default FileUpload;
