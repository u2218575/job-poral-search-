import React, { useContext, useEffect } from "react";
import { useNavigate } from "react-router";
import AuthContext from "../context/auth-context";

const Home = () => {
  const auth = useContext(AuthContext);
  const navigate = useNavigate();
  var isSessionLogin = sessionStorage.getItem("isLoggedIn");

  useEffect(() => {
    if (!auth.isLoggedIn && !isSessionLogin) navigate(`/`);
    if (!auth.isLoggedIn && isSessionLogin) auth.login();
  }, [auth.isLoggedIn]);

  return <h1 className="text-justify w-full h-10">Home</h1>;
};

export default Home;
