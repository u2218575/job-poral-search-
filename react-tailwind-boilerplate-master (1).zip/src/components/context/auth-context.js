import { createContext } from "react";

const AuthContext = createContext({
  isLoggedIn: false,
  userId: "",
  login: () => {},
  logout: () => {},
  isAdmin: false,
});

export default AuthContext;

// const AuthContext = () => createContext({
//   isLoggedIn: false,
//   login: () => {},
//   logout: () => {},
// });

// export default AuthContext;
