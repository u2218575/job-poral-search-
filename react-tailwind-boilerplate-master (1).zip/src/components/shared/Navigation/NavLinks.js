import React, { useContext } from "react";
import { NavLink, useLocation, useNavigate } from "react-router-dom";
import AuthContext from "../../context/auth-context";

import "./NavLinks.css";

const NavLinks = (props) => {
  const pathname = useLocation().pathname;
  const auth = useContext(AuthContext);
  const navigate = useNavigate();
  const handleLogout = (e) => {
    auth.logout();
    navigate(`/`);
  };

  return (
    <ul className="nav-links">
      {!auth.isLoggedIn && (
        <li>
          <NavLink
            exact="true"
            to="/"
            // className={`${pathname === "/" ? loc : ""}`}
            className={() => (["/", "/"].includes(pathname) ? "active" : "")}
            onClick={props.onClick}
          >
            About Us
          </NavLink>
        </li>
      )}
      {auth.isLoggedIn && (
        <li>
          <NavLink to="/home" onClick={props.onClick}>
            HOME
          </NavLink>
        </li>
      )}
      {auth.isLoggedIn && (
        <li>
          <NavLink to="/MyProfile" onClick={props.onClick}>
            MY PROFILE
          </NavLink>
        </li>
      )}
      {auth.isLoggedIn && auth.isAdmin && (
        <li>
          <NavLink to="/ViewProfile" onClick={props.onClick}>
            View PROFILES
          </NavLink>
        </li>
      )}
      {!auth.isLoggedIn && (
        <li>
          <NavLink
            to="/Login"
            onClick={props.onClick}
            className={() =>
              ["/Login", "/Login"].includes(pathname) ? "active" : ""
            }
          >
            Login
          </NavLink>
        </li>
      )}
      {auth.isLoggedIn && (
        <li>
          <button>
            <NavLink
              to="/AboutUs"
              onClick={() => {
                handleLogout();
                props.onClick();
              }}
              className={() =>
                ["/Login", "/Login"].includes(pathname) ? "active" : ""
              }
            >
              Logout
            </NavLink>
          </button>
          {/* <NavLink to="/Login">Logout</NavLink> */}
        </li>
      )}
      {/* <li>
        <NavLink
          to="/Counter"
          onClick={props.onClick}
          className={() =>
            ["/Counter", "/Counter"].includes(pathname) ? "active" : ""
          }
        >
          Counter
        </NavLink>
      </li> */}
    </ul>
  );
};

export default NavLinks;
