import React, { useContext, useEffect, useLayoutEffect, useState } from "react";
import Backdrop from "../Backdrop/Backdrop";
import MainHeader from "./MainHeader";
import "./MainNavigation.css";
import NavLinks from "./NavLinks";
import SideDrawer from "./SideDrawer";
import orgLogo from "../../../img/orglogo.png";
import MainLogo from "../../../img/bit.png";
import { useNavigate } from "react-router";
import AuthContext from "../../context/auth-context";

const MainNavigation = (props) => {
  const auth = useContext(AuthContext);
  const navigate = useNavigate();
  const [drawerIsOpen, setdrawerIsOpen] = useState(false);

  const handleMenuOpenButton = () => {
    setdrawerIsOpen(true);
  };
  const handleMenuCloseButton = () => {
    setdrawerIsOpen(false);
  };

  const handleOrgImage = () => {
    {
      auth.isLoggedIn ? navigate(`/home`) : navigate(`/login`);
    }
  };
  const handleResize = () => {
    if (window.innerWidth > 768 && drawerIsOpen) {
      setdrawerIsOpen(false);
    }
  };

  useEffect(() => {
    if (!auth.isLoggedIn) console.log(auth);
  }, [auth]);

  useLayoutEffect(() => {
    window.addEventListener("resize", handleResize);
  });

  return (
    <React.Fragment>
      {drawerIsOpen && <Backdrop onClick={handleMenuCloseButton} />}
      {drawerIsOpen && (
        <SideDrawer>
          <nav className="main-navigation__drawer-nav">
            <NavLinks onClick={handleMenuCloseButton} />
          </nav>
        </SideDrawer>
      )}
      <MainHeader>
        <button
          className="main-navigation__menu-btn"
          onClick={handleMenuOpenButton}
        >
          <span />
          <span />
          <span />
        </button>
        {/* <h1 className="main-navigation__title">About Us</h1> */}

        <img
          className="main-navigation__OrgLogo_img"
          alt="Org Logo"
          src={orgLogo}
          onClick={handleOrgImage}
        />

        <img
          className="main-navigation__img"
          alt="Org Logo"
          src={MainLogo}
          onClick={handleOrgImage}
        />

        <nav className="main-navigation__header-nav">
          <NavLinks />
        </nav>
      </MainHeader>
    </React.Fragment>
  );
};

export default MainNavigation;
