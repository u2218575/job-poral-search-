import axios from "axios";
import { useContext, useEffect, useState } from "react";
import "../ViewProfile/ViewProfile.css";
import AuthContext from "../context/auth-context";
import { useNavigate } from "react-router";
import download from "downloadjs";
const baseUrl = process.env.REACT_APP_SERVER_URL;

const ViewProfile = () => {
  const auth = useContext(AuthContext);
  const navigate = useNavigate();
  var isSessionLogin = sessionStorage.getItem("isLoggedIn");
  const loginUserId = sessionStorage.getItem("UserId");
  const [profileData, setprofileData] = useState([]);
  useEffect(() => {
    if (!auth.isLoggedIn && !isSessionLogin) navigate(`/`);
    if (!auth.isLoggedIn && isSessionLogin) auth.login();
    fetch();
  }, [auth.isLoggedIn]);

  const fetch = async () => {
    const { data } = await axios.get(`${baseUrl}/user/get-all-userprofile`);
    setprofileData(data.allProfiles);
    console.log(data.allProfiles);
  };

  function downLoad(id, fileName, fileType, data, contentType) {
    return axios
      .get(`${baseUrl}/user/downloadFile?UId=${loginUserId}`)
      .then((res) => {
        if (res.status !== 200) {
          console.log(res);
        } else {
          const linkSource = res.data;
          const downloadLink = document.createElement("a");

          downloadLink.href = linkSource;
          downloadLink.download = fileName;
          downloadLink.click();
        }
      })
      .catch(function (error) {
        console.log(error);
      });
  }

  return (
    <>
      <h1>View Profile</h1>
      <div>
        <table className="containers" border={1}>
          <thead>
            <tr>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Email Id</th>
              <th>Mobile No</th>
              <th>Resume</th>
            </tr>
          </thead>
          <tbody>
            {profileData.length > 0 &&
              profileData.map((item, key) => (
                <tr key={item.userId}>
                  <td>{item.firstName}</td>
                  <td>{item.lastName}</td>
                  <td>{item.emailId}</td>
                  <td>{item.mobileNo}</td>
                  <td>
                    <a
                      href="#"
                      className="fileLink"
                      placeholder="Download"
                      onClick={() =>
                        downLoad(
                          item.userId,
                          JSON.parse(item?.fileName)?.fileName,
                          JSON.parse(item?.fileName)?.fileType,
                          item?.fileData?.data,
                          item?.fileData?.contentType
                        )
                      }
                    >
                      {JSON.parse(item?.fileName)?.fileName}
                    </a>
                  </td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>
    </>
  );
};

export default ViewProfile;
