import axios from "axios";
import { useContext, useEffect, useState } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import "../Login/Login.css";
//import LoadingSpinner from "../LoadingSpinner/LoadingSpinner.js";
import logo from "../../img/bit.png";
// import usrnameimg from "../../img/username.png";
// import keyimg from "../../img/key.png";
// import orgLogo from "../../img/favicons.png";
import AuthContext from "../context/auth-context";

const baseUrl = process.env.REACT_APP_SERVER_URL;

const Login = () => {
  const auth = useContext(AuthContext);
  const navigate = useNavigate();
  const [user, setUser] = useState({
    userName: "",
    password: "",
    email: "",
  });
  const [error, setError] = useState("");
  const [progress, setProgress] = useState(false);
  const [success, setSuccess] = useState(false);
  const [successData, setSuccessData] = useState({});
  const [isLogin, setIsLogin] = useState(true);
  const [IsVisible, setIsVisible] = useState(false);

  const handleOnChange = ({ target }) => {
    const { name, value } = target;
    setUser({ ...user, [name]: value });
    setError("");
  };

  const setTimer = (delay) => {
    setTimeout(() => {
      setIsVisible(false);
      setIsLogin(true);
    }, delay);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { password, email, userName } = user;
    console.log(user);
    if (!isLogin && userName?.trim().length === 0)
      return setError("User name cannot be empty");
    if (email?.trim().length === 0) return setError("Email cannot be empty");
    if (password?.trim().length === 0)
      return setError("Password cannot be empty");
    if (password?.trim().length < 8 || password?.trim().length > 20)
      return setError("Password must be 8 to 20 characters long");

    try {
      setProgress(true);
      if (isLogin) {
        await axios
          .post(`${baseUrl}/user/signin`, {
            email,
            password,
          })
          .then((response) => {
            setSuccess(true);
            setSuccessData(response.data);
            console.log(successData);

            sessionStorage.setItem("UserId", response.data.user.id);
            sessionStorage.setItem("isAdmin", response.data.user.isAdmin);
            // let adm = response.data.user.isAdmin;
            // auth.isAdmin = response.data.user.isAdmin;
            // auth.userId = response.data.user.id;
            setProgress(false);
            setIsVisible(true);
            setTimer(3000);
            auth.login();
            navigate(`/home`);
          })
          .catch((error) => {
            setProgress(false);
            setUser({ userName: "", email: "", password: "" });
            console.log(error);
            setError(error.message);
            setIsVisible(true);
            setTimer(3000);
          });
      } else if (!isLogin) {
        await axios
          .post(`${baseUrl}/user/create`, {
            email,
            password,
            name: userName,
          })
          .then((response) => {
            setSuccess(true);
            setSuccessData(response.data);
            console.log(successData);
            setProgress(false);
            setIsVisible(true);
            setTimer(3000);
            navigate(`/login`);
          })
          .catch((error) => {
            setProgress(false);
            setUser({ userName: "", email: "", password: "" });
            console.log(error);
            setIsVisible(true);
            setError(error.response?.data?.error);
          });
      }

      // const { data } = await setInterval(() => {
      //   axios.post(`${baseUrl}/user/signin`, {
      //     email,
      //     password,
      //   })};
      //   if (data?.success) {
      //     setProgress(false);
      //     setSuccessData(data);
      //     setSuccess(true);
      //     console.log(data);
      //     navigate(`/home`);
      //   }
      // .then((response) => {
      //   console.log(response);

      //   if (response.data?.success) {

      //     //
      //
      //   }
      // })
      // .catch((error) => {

      // });
      // }, 0);
    } catch (error) {
      setProgress(false);
      setTimer(3000);
      setUser({ userName: "", email: "", password: "" });
      console.log(error);
    }
  };

  const handleSignup = () => {
    isLogin ? setIsLogin(false) : setIsLogin(true);
    console.log(!isLogin);
  };

  return (
    <div className="container">
      {progress ? (
        <div id="semiTransparenDiv"></div>
      ) : (
        <>
          {/* <div className="max-w-screen-sm m-auto pt-40">
            <h1 className="text-center text-3xl text-gray-35 font-weight-bold margin-0">
              Login
            </h1>
            <form
              action=""
              onSubmit={handleSubmit}
              className="shadow w-full rounded-lg p-10"
            >
              {error && (
                <p className="text-center p-2 mb-3 bg-red-500 text-white">
                  {error}
                </p>
              )}
              {!progress && success && (
                <p className="text-center p-2 mb-3 bg-green-500 text-white">
                  {success}
                </p>
              )}
              <div className="space-y-6">
                {!isLogin && (
                  <input
                    type="text"
                    placeholder="Name"
                    name="userName"
                    onChange={handleOnChange}
                    className="px-3 text-lg h-10 w-full border-gray-500 border-2 rounded"
                  />
                )}

                <input
                  type="text"
                  placeholder="Email"
                  name="email"
                  onChange={handleOnChange}
                  className="px-3 text-lg h-10 w-full border-gray-500 border-2 rounded"
                />

                <input
                  type="password"
                  placeholder="********"
                  name="password"
                  onChange={handleOnChange}
                  className="px-3 text-lg h-10 w-full border-gray-500 border-2 rounded"
                />
                <input
                  type="submit"
                  value={!isLogin ? "Sign Up" : "Login"}
                  className="bg-gray-500 w-300 py-3 text-white rounded"
                  // disabled={!progress}
                ></input>
                <div className="bg-blue-5">
                  {isLogin ? "Dont have account ?" : "Already have account !"}{" "}
                  <NavLink
                    className="navbar-item"
                    onClick={handleSignup}
                    // to="/Signup"
                  >
                    {isLogin ? "Sign Up" : "Login"}
                  </NavLink>
                </div>
              </div>
            </form>{" "}
          </div> */}
          <div id="login-page" className="login-page-color">
            <div id="login-form">
              <div className="shadow-lg login-area login-area-color">
                {/* <img className="org-logo" alt="Org Logo" src={orgLogo} /> */}
                <img className="e-logo" alt="Logo" src={logo} />

                <div id="login-content">
                  {/* <div className="login-top login-top-color">
                    <span
                      className="text-center display-block"
                      id="sign-in-word"
                    >
                      Password Required
                    </span>
                  </div> */}
                  <form
                    action=""
                    onSubmit={handleSubmit}
                    className="shadow-lg w-full rounded-lg p-10"
                  >
                    {error && (
                      <p className="text-center p-2 mb-3 bg-red-500 text-white rounded-lg">
                        {error}
                      </p>
                    )}
                    {IsVisible && !progress && success ? (
                      <p className="text-center p-2 mb-3 bg-green-500 text-white">
                        {isLogin
                          ? "User Logged in Successfully!!"
                          : "User Profile Created Successfully!!"}
                      </p>
                    ) : (
                      <span />
                    )}
                    <div id="login-input-area space-y-6">
                      {!isLogin && (
                        <div className="section-div-imgUserName">
                          <input
                            type="text"
                            placeholder="Name"
                            name="userName"
                            onChange={handleOnChange}
                            className="px-3 text-lg h-10 w-full border-gray-500 border-2 rounded"
                          />
                        </div>
                      )}
                      <div className="section-div-imgEmail">
                        <input
                          type="text"
                          placeholder="Email"
                          name="email"
                          onChange={handleOnChange}
                          className="px-3 text-lg h-10 w-full border-gray-500 border-2 rounded"
                        />
                      </div>
                      {/* <img className="input-img-usr" alt="key" src={keyimg} /> */}
                      <div className="section-div-imgkey">
                        <input
                          type="password"
                          placeholder="********"
                          name="password"
                          onChange={handleOnChange}
                          className="px-3 text-lg h-10 w-full border-gray-500 border-2 rounded"
                        />
                      </div>
                      <input
                        type="submit"
                        value={!isLogin ? "Sign Up" : "Login"}
                        className="bg-gray-500 w-300 py-3 text-white rounded login-button login-button-color"
                        // disabled={!progress}
                      ></input>
                      <div className="bg-blue-5 register-login-div">
                        {isLogin
                          ? "Dont have account ?"
                          : "Already have account !"}{" "}
                        <NavLink
                          className="navbar-item"
                          onClick={handleSignup}
                          // to="/Signup"
                        >
                          {isLogin ? "Sign Up" : "Login"}
                        </NavLink>
                      </div>
                    </div>
                  </form>{" "}
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default Login;
