import React, { useEffect, useState } from "react";
import querystring from "query-string";
import { useLocation, useNavigate } from "react-router";
import axios from "axios";
const baseUrl = process.env.REACT_APP_SERVER_URL;

export default function VerifyEmail() {
  const location = useLocation();
  const navigate = useNavigate();
  const [invalidUser, setInvalidUser] = useState("");
  const [busy, setBusy] = useState(true);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  const [successData, setsuccessData] = useState({});
  const [Otp, setOtp] = useState([]);
  const [IsVisible, setIsVisible] = useState(false);

  const { token, id } = querystring.parse(location.search);
  const setTimer = (delay) => {
    setTimeout(() => {
      setIsVisible(false);
    }, delay);
  };
  const verifyToken = async () => {
    try {
      const { data } = await axios(
        `${baseUrl}/user/verify-email-token?token=${token}&id=${id}`
      );
      setsuccessData(data);
      setBusy(false);
    } catch (error) {
      if (error?.response?.data) {
        const { data } = error.response;
        if (!data.success) return setInvalidUser(data.error);

        return console.log(error.response.data);
      }
      console.log(error);
    }
  };

  useEffect(() => {
    verifyToken();
  }, []);

  const handleOnChange = ({ target }) => {
    const { name, value } = target;
    setOtp({ ...Otp, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { otp } = Otp;
    if (otp.trim().length < 1 || otp.trim().length > 4) {
      return setError("OPT must be 4 characters long");
    }

    try {
      setBusy(true);
      const { data } = await axios.post(`${baseUrl}/user/verify-email`, {
        otp,
        userId: id,
      });
      setBusy(false);

      if (data.success) {
        setSuccess(true);
        setIsVisible(true);
        setTimer(5000);
        navigate(`/login`);
      }
    } catch (error) {
      setBusy(false);
      if (error?.response?.data) {
        const { data } = error.response;
        if (!data.success) return setError(data.error);
        setIsVisible(true);
        return console.log(error.response.data);
      }
      console.log(error);
    }
  };
  if (success)
    return (
      <div className="max-w-screen-sm m-auto pt-40">
        <h1 className="text-center text-3xl text-gray-500 mb-3">
          Email Verified Successfull
        </h1>
      </div>
    );
  if (invalidUser)
    return (
      <div className="max-w-screen-sm m-auto pt-40">
        <h1 className="text-center text-3xl text-gray-500 mb-3">
          {invalidUser}
        </h1>
      </div>
    );
  if (busy)
    return (
      <div className="max-w-screen-sm m-auto pt-40">
        <h1 className="text-center text-3xl text-gray-500 mb-3">
          Wait for a moment verifying Email token.
        </h1>
      </div>
    );
  return (
    <div className="max-w-screen-sm m-auto pt-40">
      <h1 className="text-center text-3xl text-gray-500 mb-3">Verify Email</h1>
      <form
        onSubmit={handleSubmit}
        action=""
        className="shadow w-full rounded-lg p-10"
      >
        {error && (
          <p className="text-center p-2 mb-3 bg-red-500 text-white">{error}</p>
        )}
        <div className="space-y-8">
          <input
            type="text"
            placeholder="OTP"
            name="otp"
            onChange={handleOnChange}
            className="px-3 text-lg h-10 w-full border-gray-500 border-2 rounded"
          />
          <input
            type="submit"
            value="Verfiy Email"
            className="bg-gray-500 w-full py-3 text-white rounded"
          />
        </div>
      </form>
    </div>
  );
}
