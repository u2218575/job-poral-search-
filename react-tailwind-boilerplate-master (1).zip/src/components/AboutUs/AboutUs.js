import React from "react";

const AboutUs = (params) => {
  return <h1 className="justify">About Us</h1>;
};

export default AboutUs;
