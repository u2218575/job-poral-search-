import React, { useEffect, useState } from "react";

const Counter = () => {
  const [incrementCounter, setincrementCounter] = useState(0);
  const [sData, setData] = useState([]);

  function handleOnclick() {
    var c = incrementCounter;
    c++;
    setincrementCounter(c);
  }
  const fetchData = () => {
    return fetch("https://jsonplaceholder.typicode.com/users")
      .then((response) => response.json())
      .then((data) => setData(data));
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <>
      <label id="cntName">{incrementCounter}</label>

      <input id="btnCnt" type="submit" onClick={handleOnclick}></input>
      <ul>
        {sData &&
          sData.length > 0 &&
          sData.map((userObj, index) => (
            <li key={userObj.id}>{userObj.name}</li>
          ))}
      </ul>
    </>
  );
};
export default Counter;
