import React from "react";

const Footer = (params) => {
  return <h1 className="text-center">Footer</h1>;
};

export default Footer;
