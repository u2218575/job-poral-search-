import { useCallback, useEffect, useState } from "react";
import { Routes, Route } from "react-router-dom";
import Form from "./components/Form";
import Home from "./components/Home/Home";
import Login from "./components/Login/Login";

import AuthContext from "./components/context/auth-context";
import MainNavigation from "./components/shared/Navigation/MainNavigation";
import AboutUs from "./components/AboutUs/AboutUs";
import MyProfile from "./components/MyProfile/MyProfile";
import Counter from "./components/Counter/Counter";
import ViewProfile from "./components/ViewProfile/ViewProfile";
import VerifyEmail from "./components/verify-email";

const App = () => {
  const [isLoggedIn, setisLoggedIn] = useState(false);
  const [isAdmin, setisAdmin] = useState(false);
  const sessionLoginStorage = sessionStorage.getItem("isLoggedIn");
  const sessionLoginUserId = sessionStorage.getItem("UserId");
  const sessionLoginIsAdmin = sessionStorage.getItem("isAdmin");
  const login = useCallback(() => {
    let sessAdmin = sessionStorage.getItem("isAdmin");
    setisAdmin(sessAdmin.toLowerCase() === "true" ? true : false);
    setisLoggedIn(true);

    console.log("sessionLoginIsAdmin", sessionLoginIsAdmin, isAdmin);
    sessionStorage.setItem("isLoggedIn", true);
  }, []);

  const logout = useCallback(() => {
    setisLoggedIn(false);
    setisAdmin(false);
    sessionStorage.setItem("isLoggedIn", false);
    sessionStorage.setItem("UserId", "");
    sessionStorage.setItem("isAdmin", false);
  }, []);

  // useEffect(() => {
  //   {
  //     isLoggedIn && sessionLoginStorage
  //       ? sessionStorage.setItem("isLoggedIn", true)
  //       : sessionStorage.setItem("isLoggedIn", false);
  //   }
  // }, [isLoggedIn]);

  return (
    <AuthContext.Provider
      value={{
        isLoggedIn,
        sessionLoginUserId,
        login,
        logout,
        isAdmin,
      }}
    >
      <MainNavigation />
      <main>
        <Routes>
          <Route path={"/reset-password"} element={<Form />} />
          <Route path={"/verify-email"} element={<VerifyEmail />} />
          <Route exact path={"/"} element={<AboutUs />} />
          <Route path={"/Login"} element={<Login />} />
          <Route exact path={"/home"} element={<Home />} />
          <Route path={"/MyProfile"} element={<MyProfile />} />
          <Route path={"/ViewProfile"} element={<ViewProfile />} />
          {/* <Route path={"/Counter"} element={<Counter />} /> */}
        </Routes>
      </main>
    </AuthContext.Provider>
  );
};

export default App;
